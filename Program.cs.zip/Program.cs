﻿using Autofac;
using Autofac.Core;
using Autofac.Extensions.DependencyInjection;
using LogixApi_v02.DbContexts;
using LogixApi_v02.DI;
using LogixApi_v02.Helpers;
using LogixApi_v02.IRepositories;
using LogixApi_v02.Repositories;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.FileProviders;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Text;
using System.Text.Json.Serialization;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
//builder.Services.AddDbContext<ApplicationDbContext>(op => op.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
// في ConfigureServices

//builder.Services.AddHttpClient();

//builder.Services.AddDbContext<ApplicationDbContext>(options =>
//{
//    // Configure your DbContext here, for example, specify the connection string
//    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection"));
//}, ServiceLifetime.Scoped);
//builder.Services.AddHttpContextAccessor();

//// Build the service provider
//var serviceProvider = builder.Services.BuildServiceProvider();

//// Access IHttpContextAccessor
//var httpContextAccessor = serviceProvider.GetRequiredService<IHttpContextAccessor>();




//DbContextRegistration.CreateDbContextAsync(builder.Services, builder.Configuration, httpContextAccessor); // Pass the configuration here


//builder.Services.AddDbContext();
//DbContextRegistration.RegisterDbContext(services, Configuration);

builder.Services.AddScoped<ApplicationDbContext>(provider =>
{
    var httpContextAccessor = provider.GetRequiredService<IHttpContextAccessor>();
  
    
    var path = httpContextAccessor.HttpContext.Request.Path;
    if (path.HasValue && !string.IsNullOrEmpty(path.Value))
    {
        if (path.Value == "/api/users/authenticate"||path.Value == "/api/SysConfig/GetAll")
        {
            var genericConnectionString = builder.Configuration.GetConnectionString("DefaultConnection");
            return new UserDbContextFactory(genericConnectionString).CreateDbContext();
        }
    }
    var token = httpContextAccessor.HttpContext.Request.Headers["Authorization"].ToString().Replace("Bearer ", "");
    if (!string.IsNullOrEmpty(token))
    {
        // Validate and decode the JWT token
        var tokenHandler = new JwtSecurityTokenHandler();
        JwtSecurityToken jwtToken = tokenHandler.ReadJwtToken(token);

        // Extract the connection string from the decoded token
        //if (jwtToken.Payload.TryGetValue("ConnectionString", out var connectionStringValue))
        //{
        //    var userConnectionString = connectionStringValue.ToString();
        //    return new UserDbContextFactory(userConnectionString).CreateDbContext();
        //}
        if (jwtToken.Payload.TryGetValue("MemberId", out var MemberId))
        {
            var genericConnectionString = builder.Configuration.GetConnectionString("DefaultConnection");

            // Step 2: Create a new instance of the database context
            var dbContextFactory = new UserDbContextFactory(genericConnectionString);
            var dbContext = dbContextFactory.CreateDbContext();

            // Step 3: If needed, modify the connection string for the new instance
            // For example, you can change the database name in the connection string
            
            // Create a new instance of the database context with the modified connection string
         
            var memberId = MemberId.ToString();
           // var userRepository = provider.GetRequiredService<IUsersRepository>();
            var userConnectionString = GetConnectionString.GetconnactionstringByMember(dbContext, memberId).Result; // Using Result to block, consider using ConfigureAwait(false) in a real application

            return new UserDbContextFactory(userConnectionString).CreateDbContext();
        }
    }

    throw new Exception("Connection string not found in JWT token.");
});

builder.Services.AddControllers().AddJsonOptions(options =>
{
    options.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
    options.JsonSerializerOptions.WriteIndented = true;
});
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

// ==================================== Inject Repositories =======================================

builder.Host.UseServiceProviderFactory(new AutofacServiceProviderFactory());

// Call ConfigureContainer on the Host sub property 
builder.Host.ConfigureContainer<ContainerBuilder>(builder =>
{
    // ================= Repositories =======================
    builder.RegisterModule(new MainModule());
});




var appSettingsSection = builder.Configuration.GetSection("AppSettings");
var secret = appSettingsSection.GetValue<string>("Secret");
var key = Encoding.UTF8.GetBytes(secret);
builder.Services.AddAuthentication(x =>
{
    x.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    x.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
})
.AddJwtBearer(x =>
{
    x.RequireHttpsMetadata = false;
    x.SaveToken = true;
    x.TokenValidationParameters = new TokenValidationParameters
    {
        ValidateIssuer = false,
        ValidateAudience = false,
        ValidateLifetime = false,
        ValidateIssuerSigningKey = true,
        IssuerSigningKey = new SymmetricSecurityKey(key)
    };
});

builder.Services.AddAuthorization();
builder.Services.AddHttpContextAccessor();
builder.Services.AddSwaggerGen(c =>
{
    c.SwaggerDoc("v1", new OpenApiInfo
    {
        Title = "Logix API",
        Version = "v1",
        Description = " API Services.",
        Contact = new OpenApiContact
        {
            Name = "Logix Contact"
        },
    });

    c.ResolveConflictingActions(apiDescriptions => apiDescriptions.First());
    c.AddSecurityDefinition("Bearer", new OpenApiSecurityScheme
    {
        Name = "Authorization",
        Type = SecuritySchemeType.ApiKey,
        Scheme = "Bearer",
        BearerFormat = "JWT",
        In = ParameterLocation.Header,
        Description = "JWT Authorization header using the Bearer scheme."
    });

    c.AddSecurityRequirement(new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecurityScheme
                    {
                        Reference = new OpenApiReference
                        {
                            Type = ReferenceType.SecurityScheme,
                            Id = "Bearer"
                        }
                    },
                    new string[] {}
                }
            });
});
builder.Services.AddTransient<IPermissionHelper, PermissionHelper>();
var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}
//app.UseStaticFiles();
//app.UseStaticFiles(new StaticFileOptions
//{
//    FileProvider = new PhysicalFileProvider(
//    Path.Combine(Directory.GetCurrentDirectory(), "Files")),
//    RequestPath = "/qrimages"
//});
app.UseAuthentication();
app.UseAuthorization();

app.MapControllers();

app.Run();
